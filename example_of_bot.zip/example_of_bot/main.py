import logging, os

from aiogram import Bot, Dispatcher, executor
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from aiogram.contrib.fsm_storage.memory import MemoryStorage

from handlers import *
from dotenv import load_dotenv

load_dotenv()

token = os.getenv("TOKEN")
logging.basicConfig(level=logging.INFO)

bot = Bot(token=token)
dp = Dispatcher(bot, storage=MemoryStorage())
dp.middleware.setup(LoggingMiddleware())

if __name__ == '__main__':
    setup_handlers(dp, bot)
    executor.start_polling(dp, skip_updates= True)