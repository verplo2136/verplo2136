import os
from google.oauth2 import service_account
from googleapiclient.discovery import build
from datetime import date

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger

from dotenv import load_dotenv

dotenv_path = '/Users/alksandr/Desktop/bot_projector_8/keys.env'
load_dotenv(dotenv_path)

scheduler = AsyncIOScheduler()

service_account_file_path = os.getenv("SERVICE_ACCOUNT_FILE")
spreadsheet_id = os.getenv("SPREADSHEET_ID")

SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

creds = service_account.Credentials.from_service_account_file(
    service_account_file_path, scopes=SCOPES)
sheets_instance = build('sheets', 'v4', credentials=creds)
range_name = 'numbers!A:F'
max_car_columns = 5

# Google Sheets append data
async def append_data_to_sheet(user_id, phone_number):
    sheets_instance = build('sheets', 'v4', credentials=creds)

    data = [
        {
            'range': range_name,
            'values': [[user_id, phone_number]]
        }
    ]

    body = {
        'valueInputOption': 'RAW',
        'data': data
    }

    sheets_instance.spreadsheets().values().batchUpdate(spreadsheetId=spreadsheet_id, body=body).execute()

async def get_data_from_file():
    result = sheets_instance.spreadsheets().values().get(
        spreadsheetId=spreadsheet_id, 
        range=range_name
    ).execute()
    
    values = result.get('values', [])
    return values
    
async def check_user_registered(phone_number) -> bool:
    sheet_data = await get_data_from_file()
    for row in sheet_data:
        for cell in row[1:6]:  # обозначает колонки B-F
            if cell == str(phone_number):
                return True
    return False

async def get_all_registered_users():
    sheet_data = await get_data_from_file()
    return sheet_data[1:]

async def add_car_number(user_id, car_number):
    sheet_data = await get_data_from_file()
    for row in sheet_data:
        if row[0] == str(user_id):
            for i in range(1, max_car_columns+1):
                if not row[i]:
                    row[i] = car_number
                    break
            else:
                # If there are already max_car_columns car numbers, add a new column
                row.append(car_number)
            update_data_in_file(sheet_data)
            break

def update_data_in_file(sheet_data):
    sheets_instance.spreadsheets().values().update(
        spreadsheetId=spreadsheet_id, 
        range=range_name,
        body={"values": sheet_data},
        valueInputOption="USER_ENTERED"
    ).execute()

async def clear_car_numbers():
    sheet_data = await get_data_from_file()
    for row in sheet_data:
        for i in range(1, len(row)):
            row[i] = ''
    update_data_in_file(sheet_data)

async def remove_empty_columns():
    sheet_data = await get_data_from_file()
    max_len = max(len(row) for row in sheet_data)
    for i in range(max_len-1, 0, -1):
        if all(len(row)<=i or not row[i] for row in sheet_data):
            for row in sheet_data:
                if len(row)>i:
                    del row[i]
    update_data_in_file(sheet_data)

def daily_task():
    clear_car_numbers()
    remove_empty_columns()

scheduler.add_job(daily_task, IntervalTrigger(days=1))
scheduler.start()
  
