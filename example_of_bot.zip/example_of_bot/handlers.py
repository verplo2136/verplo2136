import re
import markups as nav

from aiogram import types
from aiogram.dispatcher import FSMContext

from markups import *
from google_sheets import check_user_registered

def setup_handlers(dp, bot):  
    @dp.message_handler(commands=['start'])
    async def command_start(message: types.Message):
        await bot.send_message(message.from_user.id, 'Привіт, {0.first_name}! \nЯ бот-асистент в ЖК. Щоб зареєструватися, нажміть /registration'.format(message.from_user))   

    @dp.message_handler(commands=['registration'])
    async def registration(message: types.Message):
        user_id = message.from_user.id
        
        await bot.send_message(user_id, "Для реєстрації у боті, будь ласка, відправте ваш номер телефону, натиснувши на кнопку меню.", reply_markup = nav.contact_menu)
        
    @dp.message_handler(content_types=types.ContentType.CONTACT)
    async def process_contact(message: types.Message):
        user_id = message.from_user.id
        phone_number = message.contact.phone_number
        
        if await check_user_registered(phone_number):
            await message.answer(f"Номер отримано успішно: {phone_number}. Дякую за реєстрацію!", reply_markup = nav.main_menu)
        else:
            await message.answer(f"Номер телефону: {phone_number} не знайдено у базі даних! Якщо сталася помилка, будь ласка, зверніться до охорони ЖК.")
            await bot.send_message(user_id, 'Телеграм: @telegram.\nМобільний номер: +380 00 000 0000.')
            await bot.send_sticker(user_id, "CAACAgIAAxkBAAPMZHd8khv2rBg4NQudB9pwd13QWo8AAjMAAyRxYhpDbKxj0xan4C8E")
            return

    @dp.message_handler(commands=['help'])
    async def help_command(message: types.Message):
        commands = {
            '/start': 'Розпочати роботу з ботом',
            '/registration': 'Реєстрація',
            '/help': 'Показати список доступних команд'
        }
        help_text = "Доступні команди:\n\n"
        for command, description in commands.items():
            help_text += f"\t\t{command} - {description}\n"
        await bot.send_message(message.from_user.id, help_text)
        
    @dp.message_handler(content_types=types.ContentType.STICKER)
    async def sticker_handler(message: types.Message):
        print(message.sticker.file_id)

    @dp.message_handler()
    async def main_menu_handler(message: types.Message):
        user_id = message.from_user.id
        
        match message.text:
            case 'Повернутись':
                await bot.send_message(user_id, "Повертаємось у головне меню...", reply_markup = nav.main_menu)
            case 'Створити заявку':
                await bot.send_message(user_id, 'Будь ласка, оберіть мету заявки.', reply_markup = nav.goal_menu)
            case 'Стан заявок':
                 pass
            case 'Таксі':
                await bot.send_message(user_id, 'Введіть номер автомобіля таксі.')
            case 'Контакти охорони':
                await bot.send_message(user_id, 'Телеграм: @telegram.\nМобільний номер: +380 00 000 0000.')
            case 'Гості':
                await bot.send_message(user_id, message.text, reply_markup = nav.guests_menu)
            case 'Проблеми з парковкою':
                await bot.send_message(user_id, message.text, reply_markup = nav.parking_menu)