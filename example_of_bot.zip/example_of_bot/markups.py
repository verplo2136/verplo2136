from aiogram.types import ReplyKeyboardMarkup, KeyboardButton

back_btn = KeyboardButton('Повернутись')

# Main Menu
main_menu = ReplyKeyboardMarkup(resize_keyboard=True)
main_menu.add(
    KeyboardButton('Створити заявку'),
    KeyboardButton('Стан заявок'),
    KeyboardButton('Контакти охорони'),
)

# Contact menu
contact_menu = ReplyKeyboardMarkup(resize_keyboard=True)
contact_menu.add(KeyboardButton(text="Відправити номер телефону", request_contact=True))

# Goal options menu
goal_menu = ReplyKeyboardMarkup(resize_keyboard = True, one_time_keyboard=True)
goal_menu.add(
    KeyboardButton('Таксі'),
    KeyboardButton("Кур'єр"),
    KeyboardButton("Гості"),
    KeyboardButton("Проблеми з парковкою"),
    KeyboardButton("Інше"),
    back_btn
)

# Guests menu
guests_menu = ReplyKeyboardMarkup(resize_keyboard = True)
guests_menu.add(
    KeyboardButton('З авто'),
    KeyboardButton("Гості без авто"),
    back_btn
)

# Parking menu
parking_menu = ReplyKeyboardMarkup(resize_keyboard = True)
parking_menu.add(
    KeyboardButton('Ваш автомобіль заблокований'),
    KeyboardButton("Автомобіль стоїть в недозволеному місці"),
    back_btn
)

# Checkpoint menu
checkpoint_menu = ReplyKeyboardMarkup(resize_keyboard = True)
checkpoint_menu.add(
    KeyboardButton('Перший КПП - головний'),
    KeyboardButton('Другий КПП - боковий'),
    KeyboardButton('Невідомо'),
    back_btn
)